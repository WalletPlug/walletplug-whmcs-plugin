<?php
declare(strict_types=1);

/*
 * WalletPlug Webhook Callback for WHMCS
 * Place in WHMCS: /modules/gateways/callback/walletplug.php
 */

use function json_decode;

// WHMCS bootstrap
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';

$gatewayModuleName = 'walletplug';
$gatewayParams = getGatewayVariables($gatewayModuleName);
if (!$gatewayParams || empty($gatewayParams['type'])) {
    http_response_code(503);
    exit('Module not activated');
}

// Helpers
if (!function_exists('dk_getallheaders')) {
    function dk_getallheaders(): array {
        if (function_exists('getallheaders')) {
            $h = getallheaders();
            return is_array($h) ? $h : [];
        }
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (str_starts_with($name, 'HTTP_')) {
                $key = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))));
                $headers[$key] = $value;
            }
        }
        return $headers;
    }
}

$raw = file_get_contents('php://input') ?: '';
$payload = json_decode($raw, true);
if (!is_array($payload)) {
    logTransaction('WalletPlug', ['error' => 'Invalid JSON'], 'Error');
    http_response_code(400);
    exit('Invalid JSON');
}

$headers = dk_getallheaders();
$receivedSig = $headers['X-Signature'] ?? ($headers['X_SIGNATURE'] ?? ($headers['x-signature'] ?? ''));
$secret = (string)($gatewayParams['webhookSecret'] ?? '');

if ($secret !== '') {
    if ($receivedSig === '') {
        logTransaction('WalletPlug', ['error' => 'Missing signature', 'payload' => $payload], 'Error');
        http_response_code(401);
        exit('Signature required');
    }
    $expected = 'sha256=' . hash_hmac('sha256', $raw, $secret);
    if (!hash_equals($expected, $receivedSig)) {
        logTransaction('WalletPlug', ['error' => 'Invalid signature', 'expected' => $expected, 'received' => $receivedSig], 'Error');
        http_response_code(401);
        exit('Invalid signature');
    }
}

// Extract fields
$status = strtolower((string)($payload['status'] ?? ''));
$data = is_array($payload['data'] ?? null) ? $payload['data'] : [];
$refTrx = (string)($data['ref_trx'] ?? ($payload['ref_trx'] ?? ''));
$txnId = (string)($data['transaction_id'] ?? $refTrx);
$amount = (float)($data['amount'] ?? 0.0);
$invoiceId = (int)$refTrx; // We send invoice id as ref_trx

try {
    checkCbInvoiceID($invoiceId, $gatewayModuleName);
} catch (Throwable $e) {
    logTransaction('WalletPlug', ['error' => 'Invalid invoice', 'message' => $e->getMessage(), 'payload' => $payload], 'Error');
    http_response_code(404);
    exit('Invoice not found');
}

// Avoid duplicate transaction entries
try {
    checkCbTransID($txnId);
} catch (Throwable $e) {
    // If duplicate and status is not success, just log and OK
    if (in_array($status, ['completed', 'success', 'paid'], true)) {
        logTransaction('WalletPlug', ['warning' => 'Duplicate transaction', 'txn' => $txnId], 'Error');
    }
    http_response_code(200);
    exit('OK');
}

switch ($status) {
    case 'completed':
    case 'success':
    case 'paid':
        // Apply payment to invoice
        addInvoicePayment($invoiceId, $txnId, $amount, 0.0, $gatewayModuleName);
        logTransaction('WalletPlug', ['invoiceid' => $invoiceId, 'transactionid' => $txnId, 'amount' => $amount, 'status' => $status], 'Success');
        break;

    case 'failed':
    case 'error':
    case 'declined':
        logTransaction('WalletPlug', ['invoiceid' => $invoiceId, 'status' => $status, 'payload' => $payload], 'Error');
        break;

    case 'cancelled':
    case 'canceled':
        logTransaction('WalletPlug', ['invoiceid' => $invoiceId, 'status' => $status], 'Incomplete');
        break;

    case 'pending':
    case 'processing':
    case 'initiated':
    default:
        logTransaction('WalletPlug', ['invoiceid' => $invoiceId, 'status' => $status], 'Pending');
        break;
}

http_response_code(200);
exit('OK');
