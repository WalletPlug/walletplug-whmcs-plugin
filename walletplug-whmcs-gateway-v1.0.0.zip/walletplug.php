<?php
declare(strict_types=1);

/*
 * WalletPlug Payment Gateway for WHMCS (Redirect/Offsite)
 * Place this file in WHMCS: /modules/gateways/walletplug.php
 * Callback file: /modules/gateways/callback/walletplug.php
 */

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

/**
 * Module metadata
 * @return array
 */
function walletplug_MetaData(): array
{
    return [
        'DisplayName' => 'WalletPlug',
        'APIVersion' => '1.1',
        'DisableLocalCreditCardInput' => true,
        'TokenisedStorage' => false,
    ];
}

/**
 * Gateway configuration
 * @return array
 */
function walletplug_Config(): array
{
    return [
        'FriendlyName' => [
            'Type' => 'System',
            'Value' => 'WalletPlug Payment Gateway',
        ],
        'apiBaseUrl' => [
            'FriendlyName' => 'API Base URL',
            'Type' => 'text',
            'Size' => '60',
            'Default' => 'https://walletplug.coevs.com',
            'Description' => 'Your WalletPlug API base URL.',
        ],
        'merchantId' => [
            'FriendlyName' => 'Merchant ID',
            'Type' => 'text',
            'Size' => '40',
            'Description' => 'Get your Merchant ID from WalletPlug dashboard.',
        ],
        'apiKey' => [
            'FriendlyName' => 'API Key',
            'Type' => 'password',
            'Size' => '60',
            'Description' => 'Get your API Key from WalletPlug dashboard.',
        ],
        'webhookSecret' => [
            'FriendlyName' => 'Webhook Secret Key',
            'Type' => 'password',
            'Size' => '60',
            'Description' => 'Required for verifying webhook (callback) signature.',
        ],
        'testMode' => [
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Enable sandbox (no real transactions).',
        ],
    ];
}

/**
 * Generate payment link / initiate WalletPlug checkout
 * @param array $params
 * @return string HTML output
 */
function walletplug_link(array $params): string
{
    // System/info
    $systemUrl = rtrim((string)($params['systemurl'] ?? ''), '/');
    $invoiceId = (int)($params['invoiceid'] ?? 0);
    $amount = (float)($params['amount'] ?? 0.0);
    $currency = (string)($params['currency'] ?? 'USD');

    // Gateway config
    $apiBaseUrl = (string)($params['apiBaseUrl'] ?? '');
    $merchantId = (string)($params['merchantId'] ?? '');
    $apiKey = (string)($params['apiKey'] ?? '');
    $testMode = !empty($params['testMode']) ? 'sandbox' : 'production';

    // Validate required
    if ($invoiceId <= 0 || $amount <= 0 || empty($apiBaseUrl) || empty($merchantId) || empty($apiKey) || empty($systemUrl)) {
        return '<div class="alert alert-danger">WalletPlug is not configured correctly. Please contact support.</div>';
    }

    // Prepare payload (match WooCommerce structure for API compatibility)
    $payload = [
        'payment_amount' => $amount,
        'currency_code' => $currency,
        'ref_trx' => (string)$invoiceId,
        'description' => 'Invoice #' . $invoiceId,
        'success_redirect' => $systemUrl . '/viewinvoice.php?id=' . $invoiceId,
        'failure_url' => $systemUrl . '/viewinvoice.php?id=' . $invoiceId,
        'cancel_redirect' => $systemUrl . '/viewinvoice.php?id=' . $invoiceId,
        'ipn_url' => $systemUrl . '/modules/gateways/callback/walletplug.php',
    ];

    // Call WalletPlug API to create a payment session
    $paymentUrl = null;
    $error = null;

    try {
        $base = rtrim((string)$apiBaseUrl, '/');
        if (preg_match('#/api/v\d+#i', $base)) {
            $endpointUrl = $base . '/initiate-payment';
        } elseif (preg_match('#/api/?$#i', $base)) {
            $endpointUrl = rtrim($base, '/') . '/v1/initiate-payment';
        } else {
            $endpointUrl = $base . '/api/v1/initiate-payment';
        }

        $headers = [
            'Accept: application/json',
            'Content-Type: application/json',
            'X-Environment: ' . $testMode,
            'X-Merchant-Key: ' . $merchantId,
            'X-API-Key: ' . $apiKey,
            'User-Agent: WHMCS WalletPlug Module/1.0'
        ];

        $ch = curl_init($endpointUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_POSTREDIR => 3,
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
        ]);
        $response = curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($response === false) {
            $error = 'cURL error: ' . curl_error($ch);
        }
        curl_close($ch);

        if ($error === null && $httpCode >= 200 && $httpCode < 300) {
            $data = json_decode((string)$response, true);
            if (is_array($data) && !empty($data['payment_url']) && filter_var($data['payment_url'], FILTER_VALIDATE_URL)) {
                $paymentUrl = $data['payment_url'];
            } else {
                $error = 'Invalid response from WalletPlug API.';
            }
        } elseif ($error === null) {
            $error = 'HTTP ' . $httpCode . ' from WalletPlug API';
        }
    } catch (\Throwable $e) {
        $error = 'Exception: ' . $e->getMessage();
    }

    if (!function_exists('logTransaction')) {
        // In WHMCS runtime this exists; here for distribution safety.
        // no-op
    } else {
        logTransaction('WalletPlug', [
            'request' => $payload,
            'response' => isset($response) ? json_decode((string)$response, true) : null,
            'httpCode' => $httpCode ?? null,
            'error' => $error,
        ], $error ? 'Error' : 'Success');
    }

    if ($paymentUrl) {
        $html = '<div class="text-center">'
            . '<a class="btn btn-primary" href="' . htmlspecialchars($paymentUrl, ENT_QUOTES, 'UTF-8') . '" rel="noopener" target="_top">'
            . '<i class="fa fa-lock"></i> Pay Securely with WalletPlug'
            . '</a>'
            . '</div>';
        return $html;
    }

    return '<div class="alert alert-danger">Unable to initiate WalletPlug payment. ' . htmlspecialchars((string)$error, ENT_QUOTES, 'UTF-8') . '</div>';
}

/**
 * Refund is not implemented here. This can be added later if WalletPlug exposes a refund endpoint.
 * @param array $params
 * @return array
 */
function walletplug_refund(array $params): array
{
    return [
        'status' => 'error',
        'rawdata' => 'Refund not supported via module',
    ];
}
